<?php
	function getId($text)
	{
		$partes = explode("<a href=\"parlamentar_mostrar_proc?cod_parlamentar=", $text);
		$partes_partes = explode("\">", $partes[1]);
		return str_replace("\n", "",$partes_partes[0]);
	}
	function getNome($text)
	{
		$partes = explode("<a href=\"parlamentar_mostrar_proc?cod_parlamentar=", $text);
		$partes_partes = explode("\">", $partes[1]);
		$partes_final = explode("</a>", $partes_partes[1]);
		return str_replace("\n", "",$partes_final[0]);
	}
	function getPartido($text)
	{
		$partes = explode("<span class=\"texto\">", $text);
		$partes_partes = explode("</span>", $partes[1]);
		return str_replace("\n", "",$partes_partes[0]);
	}
	function getImg($id)
	{
		/*
		$partes = explode("<img class=\"vereadorFoto\" id=\"parlamentar\" src=\"", $text);
		$partes_partes = explode("\">", $partes[1]);
		*/

		return "http://sagl.campinas.sp.leg.br/sapl_documentos/parlamentar/fotos/".$id."_foto_parlamentar";
	}

	function short_desc($text)
	{
		$quantidade = count($text);
		$res = "";
		$i = 0;
		while($i < 250)
		{
			$res .= $quantidade{$i};
			$i++;
		}
		$res .= "...";
	}
	$site = file_get_contents("http://sagl.campinas.sp.leg.br/consultas/parlamentar/parlamentar_index_html");
	$partes = explode("<div class=\"tileItem\"", $site);
	$i = 1;
	$linhas = array();
	while($i < count($partes))
	{
		$id = getId($partes[$i]);
		$nome = getNome($partes[$i]);
		$partido = getPartido($partes[$i]);
		$img = getImg($id);
		$valores = "";
		
		//echo $id." - ".$nome." - ".$partido." - ".$img."\n<br>";
		$vereador = array("id" => $id,
							"nome" => $nome,
							"partido" => $partido,
							"img" => $img);
		$linhas[] = $vereador;
		$i++;
	}
	echo json_encode($linhas);

?>