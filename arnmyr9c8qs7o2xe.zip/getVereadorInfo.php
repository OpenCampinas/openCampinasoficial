<?php
	function getDataNascimento($text)
	{
		$partes = explode("<b>Data Nascimento: </b>", $text);
		$partes_partes = explode("<", $partes[1]);
		return $partes_partes[0];
	}
	function getTelefone($text)
	{
		$partes = explode("<b>Telefone: </b>", $text);
		$partes_partes = explode("<", $partes[1]);
		return $partes_partes[0];
	}
	function getEmail($text)
	{
		$partes = explode("<b>E-mail: </b>", $text);
		$partes_partes = explode("<", $partes[1]);
		return $partes_partes[0];
	}
	function getProposituras($text)
	{
		$partes = explode("Indicação", $text);
		$partes_partes = explode("<a href=\"", $partes[0]);
		return str_replace(">", "", $partes_partes[1]);
	}
	function getBiografia($text)
	{
		$site = strip_tags(file_get_contents("http://sagl.campinas.sp.leg.br/consultas/parlamentar/biografia/biografia_index_html?cod_parlamentar=$text"),"<p>");
		/*
		$partes = explode("<p align=\"justify\">", $site);
		$partes_final = explode("</p>", $partes[1]);

		return $partes_final[0];
		*/
		return $site;

	}
	$id = @$_GET["id"];
	$site = file_get_contents("http://sagl.campinas.sp.leg.br/consultas/parlamentar/parlamentar_mostrar_proc?cod_parlamentar=$id");
	
	/*
	http://sagl.campinas.sp.leg.br/consultas/materia/materia_pesquisar_proc?incluir=0&
	existe_ocorrencia=0&
	lst_tip_materia=9&
	txt_numero=&
	txt_prot_pref=&
	txt_ano=2017&
	txt_npc=&
	txt_num_protocolo=&
	dt_apres=&
	dt_apres2=&
	dt_public=&
	dt_public2=&
	hdn_txt_autor=&
	hdn_cod_autor=371&
	lst_tip_autor=Parlamentar&lst_cod_partido=&txt_relator=&txt_assunto=&rad_tramitando=&rad_audiencia_publica=&lst_localizacao=&lst_status=&rd_ordenacao=1&chk_coautor=0&lst_passou=&btn_materia_pesquisar=Pesquisar*/
	$data_nascimento = getDataNascimento($site);
	$telefone = getTelefone($site);
	$email = getEmail($site);
	$biografia = getBiografia($id);
	$linhas = array(	"data" => $data_nascimento,
						"telefone" => $telefone,
						"email" => $email,
						"biografia" => $biografia
						);
	
	echo json_encode($linhas);

?>